package habilitacionpoo1_1152525;

import control.Controlador;
import vista.*;

public class HabilitacionPOO1_1152525 {

    public HabilitacionPOO1_1152525() {

        JFPrincipal jfp = new JFPrincipal();
        JFTrabajadores jft = new JFTrabajadores();
        JFEvaluacionesMedicas jfe = new JFEvaluacionesMedicas();
        JFAccidentes jfa = new JFAccidentes();
        JFSupervisores jfs = new JFSupervisores();

        Controlador controlador = new Controlador(jfp, jft, jfe, jfa, jfs);

        jfp.setVisible(true);
    }

    public static void main(String[] args) {
        new HabilitacionPOO1_1152525();
    }
}
