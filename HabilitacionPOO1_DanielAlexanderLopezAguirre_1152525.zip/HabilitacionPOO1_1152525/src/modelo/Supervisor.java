/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author estudiantes
 */
public class Supervisor {
    private String nombre;
    private String cargo;
    private String especialidad;
    private String horario;

    public Supervisor() {
    }

    public Supervisor(String nombre, String cargo, String especialidad, String horario) {
        this.nombre = nombre;
        this.cargo = cargo;
        this.especialidad = especialidad;
        this.horario = horario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public String getHorario() {
        return horario;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    @Override
    public String toString() {
        return "Supervisor{" + "nombre=" + nombre + ", cargo=" + cargo + ", especialidad=" + especialidad + ", horario=" + horario + '}';
    }
    
}
