/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author estudiantes
 */
public class Trabajador {
    private int numeroId;
    private String nombre;
    private String direccion;
    private String numeroTelefono;
    private String cargo;
    private String fechaIngreso;
    private String capacitaciones;

    public Trabajador() {
    }

    public Trabajador(int numeroId, String nombre, String direccion, String numeroTelefono, String cargo, String fechaIngreso, String capacitaciones) {
        this.numeroId = numeroId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.numeroTelefono = numeroTelefono;
        this.cargo = cargo;
        this.fechaIngreso = fechaIngreso;
        this.capacitaciones = capacitaciones;
    }

    
    public int getNumeroId() {
        return numeroId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getNumeroTelefono() {
        return numeroTelefono;
    }

    public String getCargo() {
        return cargo;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public String getCapacitaciones() {
        return capacitaciones;
    }

    public void setNumeroId(int numeroId) {
        this.numeroId = numeroId;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setNumeroTelefono(String numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public void setCapacitaciones(String capacitaciones) {
        this.capacitaciones = capacitaciones;
    }

    @Override
    public String toString() {
        return "Trabajador{" + "numeroId=" + numeroId + ", nombre=" + nombre + ", direccion=" + direccion + ", numeroTelefono=" + numeroTelefono + ", cargo=" + cargo + ", fechaIngreso=" + fechaIngreso + ", capacitaciones=" + capacitaciones + '}';
    }
    
}
