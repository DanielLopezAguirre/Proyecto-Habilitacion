package modelo;

import java.util.ArrayList;

public class GestorM {

    private ArrayList<Trabajador> trabajadores;
    private ArrayList<EvaluacionMedica> evaluaciones;
    private ArrayList<IncidenteAccidente> incidentes;
    private ArrayList<Supervisor> supervisores;

    public GestorM() {
        trabajadores = new ArrayList<>();
        evaluaciones = new ArrayList<>();
        incidentes = new ArrayList<>();
        supervisores = new ArrayList<>();
    }

    //trabajadores

    public boolean registrarTrabajador(int id, String nombre, String direccion, String telefono, String cargo, String fechaIngreso, String capacitaciones) {

        if (buscarTrabajadorPorNombreObj(nombre) != null) return false;

        Trabajador t = new Trabajador(id, nombre, direccion, telefono, cargo, fechaIngreso, capacitaciones);
        trabajadores.add(t);
        return true;
    }

    public boolean borrarTrabajador(String nombre) {
        Trabajador t = buscarTrabajadorPorNombreObj(nombre);
        if (t != null) {
            trabajadores.remove(t);
            return true;
        }
        return false;
    }

    public String consultarTrabajadorPorNombre(String nombre) {
        Trabajador t = buscarTrabajadorPorNombreObj(nombre);
        return (t != null) ? t.toString() : null;
    }

    public String consultarTrabajadorPorId(String id) {
        Trabajador t = buscarTrabajadorPorIdObj(id);
        return (t != null) ? t.toString() : null;
    }

    public String consultarTrabajadoresPorCargo(String cargo) {
        String salida = "";
        for (Trabajador t : trabajadores) {
            if (t.getCargo().equalsIgnoreCase(cargo)) {
                salida += t.toString() + "\n";
            }
        }
        return salida.isEmpty() ? null : salida;
    }

    public boolean actualizarTrabajador(int id, String nombre, String direccion, String telefono, String cargo, String fechaIngreso, String capacitaciones) {

        Trabajador t = buscarTrabajadorPorNombreObj(nombre);
        if (t == null) return false;

        t.setNumeroId(id);
        t.setDireccion(direccion);
        t.setNumeroTelefono(telefono);
        t.setCargo(cargo);
        t.setFechaIngreso(fechaIngreso);
        t.setCapacitaciones(capacitaciones);
        return true;
    }

    private Trabajador buscarTrabajadorPorNombreObj(String nombre) {
        for (Trabajador t : trabajadores) {
            if (t.getNombre().equalsIgnoreCase(nombre)) {
                return t;
            }
        }
        return null;
    }

    private Trabajador buscarTrabajadorPorIdObj(String id) {
        for (Trabajador t : trabajadores) {
            if (String.valueOf(t.getNumeroId()).equals(id)) {
                return t;
            }
        }
        return null;
    }

    //evaluaciones medicas

    public boolean registrarEvaluacion(String idEval, String idTrabajador, String estado, String riesgo) {

        Trabajador t = buscarTrabajadorPorIdObj(idTrabajador);
        if (t == null) return false;

        EvaluacionMedica e = new EvaluacionMedica(idEval, t, estado, riesgo);
        evaluaciones.add(e);
        return true;
    }

    public String consultarEvaluacionesPorTrabajador(String idTrabajador) {
        Trabajador t = buscarTrabajadorPorIdObj(idTrabajador);
        if (t == null) return null;

        String salida = "";
        for (EvaluacionMedica e : evaluaciones) {
            if (e.getTrabajador().equals(t)) {
                salida += e.toString() + "\n";
            }
        }
        return salida.isEmpty() ? null : salida;
    }

    public boolean actualizarEvaluacion(String idEval, String estado, String riesgo) {
        for (EvaluacionMedica e : evaluaciones) {
            if (e.getId().equals(idEval)) {
                e.setEstadoSalud(estado);
                e.setRiesgosMineria(riesgo);
                return true;
            }
        }
        return false;
    }

    //incidentes o accidentes
    public boolean registrarIncidente(String idEvento, String tipo, String fecha, String descripcion, String idTrabajador) {

        Trabajador t = buscarTrabajadorPorIdObj(idTrabajador);
        if (t == null) return false;

        IncidenteAccidente ia = new IncidenteAccidente(tipo, fecha, descripcion, t,idEvento);
        incidentes.add(ia);
        return true;
    }

    public boolean actualizarIncidente(String idEvento, String tipo, String fecha, String descripcion) {

        for (IncidenteAccidente ia : incidentes) {
            if (ia.getId().equals(idEvento)) {
                ia.setTipo(tipo);
                ia.setFecha(fecha);
                ia.setDescripcion(descripcion);
                return true;
            }
        }
        return false;
    }

    public String consultarIncidentesPorTipo(String tipo) {
        String salida = "";
        for (IncidenteAccidente ia : incidentes) {
            if (ia.getTipo().equalsIgnoreCase(tipo)) {
                salida += ia.toString() + "\n";
            }
        }
        return salida.isEmpty() ? null : salida;
    }

    public String consultarIncidentesPorFecha(String fecha) {
        String salida = "";
        for (IncidenteAccidente ia : incidentes) {
            if (ia.getFecha().equals(fecha)) {
                salida += ia.toString() + "\n";
            }
        }
        return salida.isEmpty() ? null : salida;
    }

    public String consultarIncidentesPorTrabajador(String idTrabajador) {
        Trabajador t = buscarTrabajadorPorIdObj(idTrabajador);
        if (t == null) return null;

        String salida = "";
        for (IncidenteAccidente ia : incidentes) {
            if (ia.getTrabajador().equals(t)) {
                salida += ia.toString() + "\n";
            }
        }
        return salida.isEmpty() ? null : salida;
    }

    //supervisores
    public boolean registrarSupervisor(String nombre, String cargo,
                                       String especialidad, String horario) {

        if (buscarSupervisorPorNombreObj(nombre) != null) return false;

        Supervisor s = new Supervisor(nombre, cargo, especialidad, horario);
        supervisores.add(s);
        return true;
    }

    public boolean actualizarSupervisor(String nombre, String cargo,
                                        String especialidad, String horario) {

        Supervisor s = buscarSupervisorPorNombreObj(nombre);
        if (s == null) return false;

        s.setCargo(cargo);
        s.setEspecialidad(especialidad);
        s.setHorario(horario);
        return true;
    }

    public String buscarSupervisorPorNombre(String nombre) {
        Supervisor s = buscarSupervisorPorNombreObj(nombre);
        return (s != null) ? s.toString() : null;
    }

    public String buscarSupervisoresPorCargo(String cargo) {
        String salida = "";
        for (Supervisor s : supervisores) {
            if (s.getCargo().equalsIgnoreCase(cargo)) {
                salida += s.toString() + "\n";
            }
        }
        return salida.isEmpty() ? null : salida;
    }

    private Supervisor buscarSupervisorPorNombreObj(String nombre) {
        for (Supervisor s : supervisores) {
            if (s.getNombre().equalsIgnoreCase(nombre)) {
                return s;
            }
        }
        return null;
    }
}