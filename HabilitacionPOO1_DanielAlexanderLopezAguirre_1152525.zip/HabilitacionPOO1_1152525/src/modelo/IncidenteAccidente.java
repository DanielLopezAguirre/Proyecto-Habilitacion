/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author estudiantes
 */
public class IncidenteAccidente {
    private String tipo;
    private String fecha;
    private String descripcion;
    private Trabajador trabajador;
    private String id;

    public IncidenteAccidente() {
    }

    public IncidenteAccidente(String tipo, String fecha, String descripcion, Trabajador trabajador, String id) {
        this.tipo = tipo;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.trabajador = trabajador;
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public String getFecha() {
        return fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getId() {
        return id;
    }

    public Trabajador getTrabajador() {
        return trabajador;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setTrabajador(Trabajador trabajador) {
        this.trabajador = trabajador;
    }

    @Override
    public String toString() {
        return "IncidenteAccidente{" + "tipo=" + tipo + ", fecha=" + fecha + ", descripcion=" + descripcion + ", trabajador=" + trabajador + ", id=" + id + '}';
    }
    
}
