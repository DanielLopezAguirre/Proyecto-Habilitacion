/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author estudiantes
 */
public class EvaluacionMedica {
    private String id;
    private Trabajador trabajador;
    private String estadoSalud;
    private String riesgosMineria;

    public EvaluacionMedica() {
    }

    public EvaluacionMedica(String id,Trabajador trabajador, String estadoSalud, String riesgosMineria) {
        this.trabajador = trabajador;
        this.estadoSalud = estadoSalud;
        this.riesgosMineria = riesgosMineria;
        this.id = id;
    }

    public Trabajador getTrabajador() {
        return trabajador;
    }

    public String getEstadoSalud() {
        return estadoSalud;
    }

    public String getRiesgosMineria() {
        return riesgosMineria;
    }

    public String getId() {
        return id;
    }
    
    public void setTrabajador(Trabajador trabajador) {
        this.trabajador = trabajador;
    }

    public void setEstadoSalud(String estadoSalud) {
        this.estadoSalud = estadoSalud;
    }

    public void setRiesgosMineria(String riesgosMineria) {
        this.riesgosMineria = riesgosMineria;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "EvaluacionMedica{" + "id=" + id + ", trabajador=" + trabajador + ", estadoSalud=" + estadoSalud + ", riesgosMineria=" + riesgosMineria + '}';
    }
    
}
