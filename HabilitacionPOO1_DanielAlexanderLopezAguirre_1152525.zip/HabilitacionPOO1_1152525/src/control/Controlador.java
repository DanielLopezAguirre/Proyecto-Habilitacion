package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.*;
import vista.*;

public class Controlador implements ActionListener {

    private GestorM gestor;

    private JFPrincipal jfPrincipal;
    private JFTrabajadores jfTrabajadores;
    private JFEvaluacionesMedicas jfEvaluaciones;
    private JFAccidentes jfAccidentes;
    private JFSupervisores jfSupervisores;

    public Controlador(JFPrincipal p,
                       JFTrabajadores t,
                       JFEvaluacionesMedicas e,
                       JFAccidentes a,
                       JFSupervisores s) {

        gestor = new GestorM();

        jfPrincipal = p;
        jfTrabajadores = t;
        jfEvaluaciones = e;
        jfAccidentes = a;
        jfSupervisores = s;

        jfPrincipal.btnTrabajadores.addActionListener(this);
        jfPrincipal.btnEvaluaciones.addActionListener(this);
        jfPrincipal.btnAccidentes.addActionListener(this);
        jfPrincipal.btnSupervisores.addActionListener(this);

        jfTrabajadores.btnRegistrar.addActionListener(this);
        jfTrabajadores.btnBorrar.addActionListener(this);
        jfTrabajadores.btnConsultar.addActionListener(this);
        jfTrabajadores.btnActualizar.addActionListener(this);

        jfEvaluaciones.btnRegistrar.addActionListener(this);
        jfEvaluaciones.btnConsultar.addActionListener(this);
        jfEvaluaciones.btnActualizar.addActionListener(this);

        jfAccidentes.btnRegistrar.addActionListener(this);
        jfAccidentes.btnConsultar.addActionListener(this);
        jfAccidentes.btnActualizar.addActionListener(this);

        jfSupervisores.btnRegistrar.addActionListener(this);
        jfSupervisores.btnActualizar.addActionListener(this);
        jfSupervisores.btnBuscar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object src = e.getSource();

        if (src == jfPrincipal.btnTrabajadores) {
            jfTrabajadores.setVisible(true);

        } else if (src == jfPrincipal.btnEvaluaciones) {
            jfEvaluaciones.setVisible(true);

        } else if (src == jfPrincipal.btnAccidentes) {
            jfAccidentes.setVisible(true);

        } else if (src == jfPrincipal.btnSupervisores) {
            jfSupervisores.setVisible(true);

        } else if (src == jfTrabajadores.btnRegistrar) {
            registrarTrabajador();

        } else if (src == jfTrabajadores.btnBorrar) {
            borrarTrabajador();

        } else if (src == jfTrabajadores.btnConsultar) {
            consultarTrabajador();

        } else if (src == jfTrabajadores.btnActualizar) {
            actualizarTrabajador();

        } else if (src == jfEvaluaciones.btnRegistrar) {
            registrarEvaluacion();

        } else if (src == jfEvaluaciones.btnConsultar) {
            consultarEvaluaciones();

        } else if (src == jfEvaluaciones.btnActualizar) {
            actualizarEvaluacion();

        } else if (src == jfAccidentes.btnRegistrar) {
            registrarIncidente();

        } else if (src == jfAccidentes.btnConsultar) {
            consultarIncidente();

        } else if (src == jfAccidentes.btnActualizar) {
            actualizarIncidente();

        } else if (src == jfSupervisores.btnRegistrar) {
            registrarSupervisor();

        } else if (src == jfSupervisores.btnActualizar) {
            actualizarSupervisor();

        } else if (src == jfSupervisores.btnBuscar) {
            buscarSupervisor();
        }
    }

    private void registrarTrabajador() {
        boolean ok = gestor.registrarTrabajador(
                Integer.parseInt(jfTrabajadores.txtIdTrabajador.getText()),
                jfTrabajadores.txtNombre.getText(),
                jfTrabajadores.txtDireccion.getText(),
                jfTrabajadores.txtTelefono.getText(),
                jfTrabajadores.txtCargo.getText(),
                jfTrabajadores.txtFecha.getText(),
                jfTrabajadores.txtCapacitaciones.getText()
        );

        if (ok) {
            jfTrabajadores.txtSalidas.setText("Trabajador registrado");
        } else {
            jfTrabajadores.txtSalidas.setText("El trabajador ya existe");
        }
    }

    private void borrarTrabajador() {
        boolean ok = gestor.borrarTrabajador(jfTrabajadores.txtNombre.getText());

        if (ok) {
            jfTrabajadores.txtSalidas.setText("Trabajador eliminado");
        } else {
            jfTrabajadores.txtSalidas.setText("No existe el trabajador");
        }
    }

    private void consultarTrabajador() {

        String parametro = jfTrabajadores.combParametrodeBusqueda.getSelectedItem().toString();
        String salida = null;

        if (parametro.equals("Nombre")) {
            salida = gestor.consultarTrabajadorPorNombre(jfTrabajadores.txtNombre.getText());

        } else if (parametro.equals("Id")) {
            salida = gestor.consultarTrabajadorPorId(jfTrabajadores.txtIdTrabajador.getText());

        } else if (parametro.equals("Cargo")) {
            salida = gestor.consultarTrabajadoresPorCargo(jfTrabajadores.txtCargo.getText());
        }

        if (salida != null) {
            jfTrabajadores.txtSalidas.setText(salida);
        } else {
            jfTrabajadores.txtSalidas.setText("Sin resultados");
        }
    }

    private void actualizarTrabajador() {
        boolean ok = gestor.actualizarTrabajador(
                Integer.parseInt(jfTrabajadores.txtIdTrabajador.getText()),
                jfTrabajadores.txtNombre.getText(),
                jfTrabajadores.txtDireccion.getText(),
                jfTrabajadores.txtTelefono.getText(),
                jfTrabajadores.txtCargo.getText(),
                jfTrabajadores.txtFecha.getText(),
                jfTrabajadores.txtCapacitaciones.getText()
        );

        if (ok) {
            jfTrabajadores.txtSalidas.setText("Información actualizada");
        } else {
            jfTrabajadores.txtSalidas.setText("No existe el trabajador");
        }
    }

    private void registrarEvaluacion() {
        boolean ok = gestor.registrarEvaluacion(
                jfEvaluaciones.txtIdEvaluacionMedica.getText(),
                jfEvaluaciones.txtIdTrabajador.getText(),
                jfEvaluaciones.txtEstadoS.getText(),
                jfEvaluaciones.txtRiesgoM.getText()
        );

        if (ok) {
            jfEvaluaciones.txtSalidas.setText("Evaluación registrada");
        } else {
            jfEvaluaciones.txtSalidas.setText("Trabajador no existe");
        }
    }

    private void consultarEvaluaciones() {
        String salida = gestor.consultarEvaluacionesPorTrabajador(
                jfEvaluaciones.txtIdTrabajador.getText()
        );

        if (salida != null) {
            jfEvaluaciones.txtSalidas.setText(salida);
        } else {
            jfEvaluaciones.txtSalidas.setText("Sin evaluaciones");
        }
    }

    private void actualizarEvaluacion() {
        boolean ok = gestor.actualizarEvaluacion(
                jfEvaluaciones.txtIdEvaluacionMedica.getText(),
                jfEvaluaciones.txtEstadoS.getText(),
                jfEvaluaciones.txtRiesgoM.getText()
        );

        if (ok) {
            jfEvaluaciones.txtSalidas.setText("Evaluación actualizada");
        } else {
            jfEvaluaciones.txtSalidas.setText("No existe la evaluación");
        }
    }

    private void registrarIncidente() {
        boolean ok = gestor.registrarIncidente(
                jfAccidentes.txtIdEvento.getText(),
                jfAccidentes.txtTipo.getText(),
                jfAccidentes.txtFecha.getText(),
                jfAccidentes.txtDescripcion.getText(),
                jfAccidentes.txtIdTrabajador.getText()
        );

        if (ok) {
            jfAccidentes.txtSalidas.setText("Incidente registrado");
        } else {
            jfAccidentes.txtSalidas.setText("Trabajador no existe");
        }
    }

    private void actualizarIncidente() {
        boolean ok = gestor.actualizarIncidente(
                jfAccidentes.txtIdEvento.getText(),
                jfAccidentes.txtTipo.getText(),
                jfAccidentes.txtFecha.getText(),
                jfAccidentes.txtDescripcion.getText()
        );

        if (ok) {
            jfAccidentes.txtSalidas.setText("Incidente actualizado");
        } else {
            jfAccidentes.txtSalidas.setText("No existe el incidente");
        }
    }

    private void consultarIncidente() {

        String parametro = jfAccidentes.combParametroDeBusqueda.getSelectedItem().toString();
        String salida = null;

        if (parametro.equals("Tipo")) {
            salida = gestor.consultarIncidentesPorTipo(jfAccidentes.txtTipo.getText());

        } else if (parametro.equals("Fecha")) {
            salida = gestor.consultarIncidentesPorFecha(jfAccidentes.txtFecha.getText());

        } else if (parametro.equals("Trabajador")) {
            salida = gestor.consultarIncidentesPorTrabajador(jfAccidentes.txtIdTrabajador.getText());
        }

        if (salida != null) {
            jfAccidentes.txtSalidas.setText(salida);
        } else {
            jfAccidentes.txtSalidas.setText("Sin resultados");
        }
    }

    private void registrarSupervisor() {
        boolean ok = gestor.registrarSupervisor(
                jfSupervisores.txtNombre.getText(),
                jfSupervisores.txtCargo.getText(),
                jfSupervisores.txtEspecialidad.getText(),
                jfSupervisores.txtHorario.getText()
        );

        if (ok) {
            jfSupervisores.txtSalida.setText("Supervisor registrado");
        } else {
            jfSupervisores.txtSalida.setText("El supervisor ya existe");
        }
    }

    private void actualizarSupervisor() {
        boolean ok = gestor.actualizarSupervisor(jfSupervisores.txtNombre.getText(), jfSupervisores.txtCargo.getText(), jfSupervisores.txtEspecialidad.getText(), jfSupervisores.txtHorario.getText()
        );

        if (ok) {
            jfSupervisores.txtSalida.setText("Supervisor actualizado");
        } else {
            jfSupervisores.txtSalida.setText("No existe el supervisor");
        }
    }

    private void buscarSupervisor() {

        String parametro = jfSupervisores.combParametro.getSelectedItem().toString();
        String salida = null;

        if (parametro.equals("Nombre")) {
            salida = gestor.buscarSupervisorPorNombre(jfSupervisores.txtNombre.getText());
        } else {
            salida = gestor.buscarSupervisoresPorCargo(jfSupervisores.txtCargo.getText());
        }

        if (salida != null) {
            jfSupervisores.txtSalida.setText(salida);
        } else {
            jfSupervisores.txtSalida.setText("Sin resultados");
        }
    }
}
